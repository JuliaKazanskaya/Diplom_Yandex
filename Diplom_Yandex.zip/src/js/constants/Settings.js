const newsApiUrl = 'https://newsapi.org/v2/everything';
const newsApiKey = 'e733d1f6586b476f96e90aa53b1379f3';
const githubUrl = 'https://api.github.com';
const githubUsername = 'JuliaBolelova';
const githubRepository = 'Diplom_Yandex';
const countArticles = 100;
const stepShow = 3;

export {
	newsApiKey, countArticles, githubUsername, githubRepository,
	stepShow, newsApiUrl, githubUrl
};