import './about.css';
import "../vendor/flickity.css"